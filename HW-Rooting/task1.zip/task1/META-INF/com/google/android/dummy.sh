echo hello > /system/dummy
